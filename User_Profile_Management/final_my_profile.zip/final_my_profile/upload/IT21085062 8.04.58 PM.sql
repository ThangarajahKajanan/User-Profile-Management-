
/*. Student(SID:CHAR(10), Sname:VARCHAR(50), Address:VARCHAR(50), dob:DATE, NIC:CHAR(10), CID:CHAR(6)).  */
/* Offers (CID:CHAR(6) , Mcode:CHAR(6), Accadamic_year:CHAR(2), Semester:INTEGER) */
/* Module (Mcode:CHAR(6), Mname:VARCHAR(50), M_Description:VARCHAR(200),NoOfCredits:INTEGER) */
/* Course (CID:CHAR(6), Cname:VARCHAR(50), C_Description:VARCHAR(200), C_fee:INTEGER) */


create database pra;
use pra;


create table Course(CID char(6), Cname varchar(50), C_Description varchar(200), C_fee integer,
constraint C_PK primary key(CID) );

create table Module(Mcode char(6), Mname varchar(50),  M_Description varchar(200), NoOfCredits integer,
constraint Module_PK primary key(Mcode));

create table Student(SID char(10),Sname varchar(50), Address varchar(50), dob date, NIC char(6), CID char(6),
constraint St_PK primary key(CID), constraint St_FK foreign key (CID) references Course(CID)  ); 

create table Offers(CID char(6), Mcode char(6), Accadamic_year char(12), Semester integer,
constraint Offers_PK primary key(CID,Mcode), 
constraint Offers_FK1 foreign key(CID) references Course(CID),
constraint Offers_FK2 foreign key(Mcode) references Module(Mcode));








